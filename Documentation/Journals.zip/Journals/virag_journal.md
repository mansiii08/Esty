Sprint 1: 03/07/2022 - 03/13/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Went through the project description and finalized overall architecture.
		- Discussed about the pros and cons of multiple techstacks to be used.
		- SetUp the github project and development environment.
	- What am I planning to work on next?
		- Learning CSS and React JS.
	- What tasks are blocked waiting on another team member?
		- None


Sprint 2: 03/14/2022 - 03/20/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Learnt React JS.
		- Started working on frontend code changes.
		- Started working on designing register page.
	- What am I planning to work on next?
		- Setup routes and server.
	- What tasks are blocked waiting on another team member?
		- None


Sprint 3: 03/21/2022 - 03/27/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Started designing Add/update flight page.
		- Engaged in creating components in the client required for frontend.
		- Helped in fixing bugs.
	- What am I planning to work on next?
		- test Add/update flght page.	 
	- What tasks are blocked waiting on another team member?
		- None



Sprint 4: 03/28/2022 - 04/03/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Designed view flight page.
		- created APIs in nodejs.
		- Flight routes, baggage routes and terminal routes.
	- What am I planning to work on next?
    	        - Check how to use Ant Design components. 
	- What tasks are blocked waiting on another team member?
		- None



Sprint 5: 04/04/2022 - 04/10/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Designed assign baggage page.
		- Helped in backend - carousal routes and baggage routes.
		- Helped in designing Assign baggage page.
	- What am I planning to work on next?
		- Validate pages and components and design gate maintainance page. 
	- What tasks are blocked waiting on another team member?
		- None


Sprint 6: 04/11/2022 - 04/17/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Design gate maintainance page(enable/disable gate)
		- Helped in backend and password hashing
		- Helped in styling.
	- What am I planning to work on next?
		- Work on deployment and review all integration.
	- What tasks are blocked waiting on another team member?
		- None



Sprint 7: 04/18/2022 - 04/24/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Worked on styling
		- Worked on backend - gate assignment logic.
		- Worked on integration of frontend and backend.
	- What am I planning to work on next?
		- Testing the application with end to end testing.
	- What tasks are blocked waiting on another team member?
		- None



Sprint 8: 04/25/2022 - 04/01/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Completed end to end testing of our application successfully.
		- Deployed it on AWS.
	- What am I planning to work on next?
		- None
	- What tasks are blocked waiting on another team member?
		- None


