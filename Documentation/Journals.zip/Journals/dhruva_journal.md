Sprint 1: 03/07/2022 - 03/13/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Read and analyzed project requirements.
		- Finalized the archietecture and overall design of our project.
		- Discussed the functional requirements of our system.
	- What am I planning to work on next?
		- Exploring various backend technologies.
	- What tasks are blocked waiting on another team member?
		- None


Sprint 2: 03/14/2022 - 03/20/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Setup the development environment and sucessfully made connections.
		- Learnt backend technologies.
		- Started working on developing login page.
	- What am I planning to work on next?
		- Get comfortable with creating APIs with React and Express.
		- Design add and update flight page.
	- What tasks are blocked waiting on another team member?
		- None


Sprint 3: 03/21/2022 - 03/27/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Completed testing of login/register.
		- Helped in resolving APIs and fixing bugs.
		- Started working on Add/update flight page.
	- What am I planning to work on next?
		- design view flight page.	 
	- What tasks are blocked waiting on another team member?
		- None



Sprint 4: 03/28/2022 - 04/03/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Helped in designing view flight page.
		- Designed and created database.
        - Helped in creating APIs in nodejs.
	- What am I planning to work on next?
        - Test pages with appropriate request and response.
	- What tasks are blocked waiting on another team member?
		- None



Sprint 5: 04/04/2022 - 04/10/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Used different and Design components.
		- Worked on Database - SQL queries and database changes.
		- Worked on backend- gate service, parsing service and terminal service.
	- What am I planning to work on next?
		- Check all functionalities in working envirom=nment.
	- What tasks are blocked waiting on another team member?
		- None


Sprint 6: 04/11/2022 - 04/17/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Worked on backend- gate service, parsing service and terminal service.
		- Worked on styling.
		- Stared working on integration of frontend and backend.
	- What am I planning to work on next?
		- Test gate mainainance page and work on deployment.
	- What tasks are blocked waiting on another team member?
		- None



Sprint 7: 04/18/2022 - 04/24/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Completed Working on backend- gate service, parsing service and terminal service.
		- Helped in styling.
		- Helped in integration of frontend and backend
	- What am I planning to work on next?
		- Testing the application with end to end testing.
	- What tasks are blocked waiting on another team member?
		- None



Sprint 8: 04/25/2022 - 04/01/2022
- Weekly Scrum Report
	- What tasks did I work on / complete?
		- Completed end to end testing of our application successfully.
		- Deployed it on AWS.
	- What am I planning to work on next?
		- None
	- What tasks are blocked waiting on another team member?
		- None

